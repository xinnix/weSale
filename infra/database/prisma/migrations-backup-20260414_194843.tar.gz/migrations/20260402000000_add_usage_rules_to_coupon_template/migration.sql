-- AlterTable
ALTER TABLE "coupon_templates" ADD COLUMN "usage_rules" TEXT;